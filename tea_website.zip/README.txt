Naama Teas — Simple website
--------------------------

Files:
- index.html
- styles.css
- scripts.js
- assets/images/hero.jpg (hero image)
- assets/images/favicon.png

How to preview locally:
1. Open index.html in a browser. For full JS/CSS behavior, you can serve the folder with a simple local server:
   - Python 3: `python -m http.server 8000` then open http://localhost:8000

How to deploy to GitHub Pages:
1. Create a new GitHub repository and push these files to the repo root (or to `gh-pages` branch).
2. In the repository settings enable "GitHub Pages" and select the branch (main) and root folder.
3. After a minute your site will be live at https://<your-username>.github.io/<repo-name>.

You can also deploy to Netlify, Vercel, or any static hosting provider by dragging the folder or connecting the GitHub repo.

Contact:
Telegram: https://t.me/noooot09
