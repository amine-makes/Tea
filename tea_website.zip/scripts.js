function showDetails(id){
  const modal = document.getElementById('modal');
  const body = document.getElementById('modal-body');
  let html = '';
  if(id==='mint'){
    html = `<h3>Moroccan Mint</h3>
    <p>Traditional and refreshing. Brew with hot water (not boiling) for 2-4 minutes and enjoy with sugar or honey.</p>
    <ul><li>Spearmint</li><li>Verbena</li><li>Rose petals</li></ul>`;
  } else if(id==='calm'){
    html = `<h3>Relax & Calm</h3>
    <p>Soothing blend for evenings. Brew 5 minutes.</p>
    <ul><li>Chamomile</li><li>Verbena</li><li>Dried lemon peel</li></ul>`;
  } else if(id==='citrus'){
    html = `<h3>Citrus Herbal</h3>
    <p>Bright, warming, and aromatic.</p>
    <ul><li>Citrosa / Lemon grass</li><li>Rosemary</li><li>Cinnamon</li></ul>`;
  }
  body.innerHTML = html;
  modal.classList.add('active');
}
function hideModal(){
  document.getElementById('modal').classList.remove('active');
}
